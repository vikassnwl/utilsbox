This package contains module named utils.py which contains useful functions and classes.
