def greet(name):
    print(f'Hello, {name}!')
